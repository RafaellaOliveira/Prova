﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova1
{
    public partial class Form2 : Form
    {

        public int contador = 0;

        public Form2()
        {
            InitializeComponent();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            contador++;
            images.ImageIndex = contador;

            if (contador >= 3)
            {
                contador = 0;
                images.ImageIndex = contador;
                TextD.Text = "É um romance de aventura escrito pelo francês Júlio Verne e lançado em 1873. A obra retrata a tentativa do cavalheiro inglês Phileas Fogg e seu valete, Passepartout, de circum-navegar o mundo em 80 dias";
               
            }
            if (contador == 0)
            {
                TextD.Text = "É um romance de aventura escrito pelo francês Júlio Verne e lançado em 1873. A obra retrata a tentativa do cavalheiro inglês Phileas Fogg e seu valete, Passepartout, de circum-navegar o mundo em 80 dias";
            }
            if (contador == 1)
            {
                TextD.Text = "A peça, situada na Dinamarca, reconta a história de como o Príncipe Hamlet tenta vingar a morte de seu pai.";
            }
            if (contador == 2)
            {
                TextD.Text = "O livro conta a história de Sérgio, um menino que é enviado para um colégio agropecuário renomado na cidade do Rio de Janeiro, denominado Ateneu.Comandado pelo diretor Aristarco, o colégio mantém regras rígidas e princípios da aristocracia da época. A obra critica a sociedade brasileira do final do século XX, tomando como metáfora o Ateneu, seu reflexo, um lugar onde vence sempre o mais forte.";
            }
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            contador--;
            images.ImageIndex = contador;

            if (contador < 0)
            {
                contador = 3;
                contador--;
                images.ImageIndex = contador;
            }
            if (contador == 0)
            {
                TextD.Text = "É um romance de aventura escrito pelo francês Júlio Verne e lançado em 1873. A obra retrata a tentativa do cavalheiro inglês Phileas Fogg e seu valete, Passepartout, de circum-navegar o mundo em 80 dias";
            }
            if (contador == 1)
            {
                TextD.Text = "A peça, situada na Dinamarca, reconta a história de como o Príncipe Hamlet tenta vingar a morte de seu pai.";
            }
            if (contador == 2)
            {
                TextD.Text = "O livro conta a história de Sérgio, um menino que é enviado para um colégio agropecuário renomado na cidade do Rio de Janeiro, denominado Ateneuo livro conta a história de Sérgio, um menino que é enviado para um colégio agropecuário renomado na cidade do Rio de Janeiro, denominado Ateneu.Comandado pelo diretor Aristarco, o colégio mantém regras rígidas e princípios da aristocracia da época. A obra critica a sociedade brasileira do final do século XX, tomando como metáfora o Ateneu, seu reflexo, um lugar onde vence sempre o mais forte.";
            }
        }
    }
}
